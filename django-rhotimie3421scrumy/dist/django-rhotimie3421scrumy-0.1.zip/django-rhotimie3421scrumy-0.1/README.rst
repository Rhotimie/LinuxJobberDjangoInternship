==================
rhotimie3421scrumy
==================

rhotimie3421scrumy is a simple django app aimed at to test the skills and abilities of an intern with username: rhotimie3421scrumy.
Each assessment comes in the form of labs, the concerned user completes these labs as at when due for grading which determines if
he/she will qualify for the next stage

Detailed documentation is in the the "docs" directory.

Quick start
===========
1. Add rhotimie3421scrumy  to your INSTALLED_APPS setting like this:
	INSTALLED_APPS = [
   	 'rhotimie3421scrumy',

	]
2. Include the rhotimie3421scrumy URLconf in your project urls.py like this:
	path('rhotimie3421scrumy/', include('rhotimie3421scrumy.urls')),

3. Run "python manage.py migrate" to create rhotimie3421scrumy models.

4. Start your development server and visit http://127.0.0.1:8000/admin/
   to create a rhotimie3421scrumy (you'll need the admin app enabled)

5. Visit http://127.0.0.1:8000/rhotimie3421scrumy/ to participate