from django.shortcuts import render
from django.http import HttpResponse


def index(request):
    return HttpResponse('my username is rhotimie3421scrumy')

# Create your views here.
