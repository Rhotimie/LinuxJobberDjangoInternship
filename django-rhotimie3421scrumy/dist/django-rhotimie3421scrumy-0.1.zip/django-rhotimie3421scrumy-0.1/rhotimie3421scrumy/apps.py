from django.apps import AppConfig


class Rhotimie3421ScrumyConfig(AppConfig):
    name = 'rhotimie3421scrumy'
